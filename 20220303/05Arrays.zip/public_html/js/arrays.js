/* 
    Created on : May, 2019 
    Author     : Liisa Auer, Oulu University of Applied Sciences
    License    : CC-BY-4.0
*/

// copy and paste here the random number generator function


function t01a() {

}

function t01b() {

}

function t01c() {

}

function t01d() {

}

function t01e() {

}

function t01f() {

}

function t02() {  

}

function t03() {

}

function t04() {    

}

function t05() {    
    let dices = ["",
        '<img alt="dice 1" src="img/noppa1.png">',
        '<img alt="dice 2" src="img/noppa2.png">',
        '<img alt="dice 3" src="img/noppa3.png">',
        '<img alt="dice 4" src="img/noppa4.png">',
        '<img alt="dice 5" src="img/noppa5.png">',
        '<img alt="dice 6" src="img/noppa6.png">'
    ];
    
}
